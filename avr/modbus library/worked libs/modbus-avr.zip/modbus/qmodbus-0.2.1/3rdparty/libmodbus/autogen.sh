#! /bin/sh
autoreconf -v --install --force || exit 1
